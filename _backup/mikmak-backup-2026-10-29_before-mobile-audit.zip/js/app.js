(()=>{
const C=window.MIKMAK||{},$=s=>document.querySelector(s),PG=document.body.dataset.page;
const PAGES=[['home','index.html'],['about','about.html'],['menu','menu.html'],['gallery','gallery.html'],['reviews','reviews.html'],['faq','faq.html'],['contact','contact.html']];
const TEL=['0695232371','082247788'],WA='355695232371',FB='https://www.facebook.com/mik.mak.3705?locale=sq_AL',IG='https://www.instagram.com/mik_mak_korce/?__d=1%2F';
/* Displayed business address [Albanian, English]. The map and the map link use MAPQ/MAPURL below (intentionally different). */
const ADDR=['Bulevardi "Republika", Rruga "Jani Dudo", Korçë, Shqipëri','"Republika" Boulevard, "Jani Dudo" Street, Korçë, Albania'];
/* Contact page location. The exact Google Place ID was not verified, so the map uses a Google Maps search for the business name + plus code. */
const MAPQ='Mik Mak, JQCM+363, Korçë',MAPURL='https://www.google.com/maps/search/?api=1&query=Mik%20Mak%2C%20JQCM%2B363%2C%20Kor%C3%A7%C3%AB';
const T={
skip:['Kalo te përmbajtja','Skip to content'],
n_home:['Kryefaqja','Home'],n_about:['Rreth nesh','About Us'],n_menu:['Menuja','Menu'],n_gallery:['Galeria','Gallery'],n_reviews:['Vlerësime','Reviews'],n_faq:['Pyetje','FAQ'],n_contact:['Kontakt','Contact'],
navOpen:['Hap navigimin','Open navigation'],navClose:['Mbyll navigimin','Close navigation'],since:['Korçë · që nga 2009','Korçë · since 2009'],
tag:['Aty ku tradita vazhdon prej brezash','Where tradition continues through generations'],
seeMenu:['Shiko menunë','See the menu'],order:['Porosit tani','Order now'],more:['Meso më shumë','Learn more'],
introH:['Mik Mak','Mik Mak'],intro:['Mik Mak është një biznes i ushqimit tradicional shqiptar në Korçë. Ofrojmë byrek, lakror me dy petë, petanik dhe pispili misri.','Mik Mak is a traditional Albanian food business in Korçë. We offer byrek, lakror with two layers of pastry (lakror me dy petë), petanik and pispili misri.'],
dishesH:['Gatime tradicionale','Traditional dishes'],galH:['Nga galeria','From the gallery'],
histH:['Historia jonë','Our history'],hist:['Mik Mak u themelua në vitin 2009 dhe sot ju ofron në Korçë ushqim tradicional shqiptar. Byrek, lakror, petanik e pispili misri — gatime që mbartin shijet e kuzhinës tradicionale dhe kërkojnë kujdes në çdo hap. Që nga 2020, këto shije mbërrijnë edhe në shtëpinë tuaj me delivery, dhe tradita vazhdon, vit pas viti.','Mik Mak was founded in 2009 and today offers traditional Albanian food in Korçë. Byrek, lakror, petanik and pispili misri are dishes that carry the flavours of traditional cooking and ask for care at every step. Since 2020, these flavours also reach your home through delivery, and the tradition goes on, year after year.'],
ordH:['Porosit','Order'],ordP:['Na telefononi ose na shkruani në WhatsApp.','Call us or message us on WhatsApp.'],
d_byrek:['Byrek','Byrek'],d_lakror:['Lakror','Lakror'],d_petanik:['Petanik','Petanik'],d_pispili:['Pispili misri','Pispili misri (cornmeal pie)'],
from:['nga','from'],
tl1:['Fillimi','The Beginning'],tl1p:['Korça njihet për kuzhinën e saj tradicionale, ku byreku dhe lakrori kanë prej kohësh vendin e tyre në tryezë. Në këtë traditë u themelua Mik Mak: një vend ku ushqimi tradicional shqiptar përgatitet e shërbehet me kujdes, me shije të njohura që të kujtojnë tryezën e shtëpisë.','Korçë is known for its traditional cuisine, where byrek and lakror have long had their place at the table. Mik Mak was founded within this tradition: a place where traditional Albanian food is prepared and served with care, with familiar flavours that recall the table at home.'],
tl2:['Fillon delivery','Delivery Begins'],tl2p:['Mik Mak filloi të pranojë porosi me delivery, duke sjellë shijet tradicionale edhe në shtëpinë e klientëve.','Mik Mak began accepting delivery orders, bringing its traditional flavours to customers\u2019 homes.'],
tl3:['Tradita vazhdon','Tradition Continues'],tl3p:['Që nga viti 2009, Mik Mak vazhdon të ruajë traditën e kuzhinës shqiptare. Gjithçka nis me përbërës të freskët dhe merr jetë në saç, siç e do tradita — me durim e vëmendje, që çdo gatim të dalë plot shije dhe të ruajë karakterin e kuzhinës tradicionale shqiptare.','Since 2009, Mik Mak has kept the tradition of Albanian cuisine alive. Everything begins with fresh ingredients and comes to life in the saç, as tradition calls for — with patience and attention, so that every dish is full of flavour and keeps the character of traditional Albanian cuisine.'],
byrek:['Byrek','Byrek'],lakror:['Lakror me dy petë','Lakror me dy petë (two-layer pie)'],petanik:['Petanik','Petanik'],pispili:['Pispili misri','Pispili misri'],
fam5:['Familjar (për pesë persona)','Family size (for five people)'],fam4:['Familjar (për katër persona)','Family size (for four people)'],pjese:['Me pjesë','Per slice'],kg:['Me kilogram','Per kilogram'],
for5:['Porcion: për pesë persona','Portion: for five people'],extra:['Shtesë','Extra'],fillings:['Mbushjet','Fillings'],
photo:['Foto','Photo'],soon:['Foto së shpejti','Photo coming soon'],
q1:['Ku ndodhet Mik Mak?','Where is Mik Mak located?'],a1:['Mik Mak ndodhet në Bulevardi "Republika", Rruga "Jani Dudo", Korçë, Shqipëri.','Mik Mak is located on "Republika" Boulevard, "Jani Dudo" Street, Korçë, Albania.'],
q2:['Si mund të porosis?','How can I order?'],a2:['Mund të porosisni duke telefonuar në numrat tanë të kontaktit ose duke na shkruar në WhatsApp.','You can order by calling our contact numbers or by messaging us on WhatsApp.'],
q3:['Cilat gatime tradicionale ofroni?','Which traditional dishes do you offer?'],a3:['Ofrojmë byrek, lakror me dy petë, petanik dhe pispili misri.','We offer byrek, lakror with two layers of pastry, petanik and pispili misri.'],
q4:['A mund të zgjedh mbushjen e byrekut dhe lakrorit?','Can I choose the filling of the byrek and lakror?'],a4:['Po, mund të zgjidhni nga mbushjet e listuara në menunë tonë.','Yes, you can choose from the fillings listed on our menu.'],
q5:['A ofroni shërbim delivery?','Do you offer delivery?'],a5:['Po, ofrojmë shërbim delivery.','Yes, we offer delivery.'],
infoH:['Të dhënat tona','Our details'],formH:['Dërgoni mesazh','Send a Message'],formNote:['Mesazhi juaj hapet në WhatsApp, ku mund të bisedoni drejtpërdrejt me ne.','Your message opens in WhatsApp, where you can chat with us directly.'],fMsg:['Mesazhi juaj','Your message'],
send:['Hap WhatsApp','Open WhatsApp'],need:['Ju lutemi shkruani mesazhin tuaj.','Please write your message.'],
mapH:['Harta','Map'],cAddr:['Adresa','Address'],cPhone:['Telefon','Phone'],cWaTxt:['Na kontaktoni','Contact us'],cMapOpen:['Hap në Google Maps','Open in Google Maps'],cNew:['hapet në një dritare të re','opens in a new tab'],locAlt:['Lokali i Mik Mak në Korçë','The Mik Mak shop in Korçë'],
socH:['Na ndiqni në rrjete sociale','Follow us on social media'],socP:['Zbuloni nga afër gatimet tona tradicionale, të sapodala nga saçi, dhe mësoni të rejat e Mik Mak.','Discover our traditional dishes up close, fresh from the saç, and keep up with the latest from Mik Mak.'],
igSub:['Tradita që vjen në shtëpinë tuaj','Tradition delivered to your home'],fbSub:['Shija më e mirë në qytet','The best taste in town'],igCta:['Na ndiqni në Instagram','Follow us on Instagram'],fbCta:['Na ndiqni në Facebook','Follow us on Facebook'],call:['Telefono','Call'],wa:['WhatsApp','WhatsApp'],

ftContact:['Kontakt','Contact'],ftFollow:['Na ndiq','Follow us'],
brand:['Mik Mak · Korçë','Mik Mak · Korçë'],sinceS:['që nga','since'],
introBig:['Shije që e sjellin traditën në tryezën tuaj','Flavours that bring tradition to your table'],
intro2:['Mik Mak ofron gatime tradicionale shqiptare në Korçë: byrek, lakror me dy petë, petanik dhe pispili misri. Zgjidhni mbushjen që ju pëlqen dhe porositni me telefon ose në WhatsApp.','Mik Mak offers traditional Albanian dishes in Korçë: byrek, lakror with two sheets of pastry, petanik and pispili misri. Choose the filling you like and order by phone or on WhatsApp.'],
ds_byrek:['12 mbushje për të zgjedhur — familjar ose me pjesë','12 fillings to choose from — family size or by the slice'],
ds_lakror:['Me dy petë dhe të njëjtat 12 mbushje — familjar ose me kilogram','With two layers of pastry and the same 12 fillings — family size or by the kilogram'],
ds_petanik:['Me fasule, ose me pulë e arra','With beans, or with chicken and walnuts'],
ds_pispili:['Me presh e gjizë, ose me mix jeshile','With leek and cottage cheese, or with mixed greens'],
ctaBig:['Gati për një porosi?','Ready to order?'],ctaP:['Na telefononi ose na shkruani në WhatsApp. Ofrojmë edhe shërbim delivery.','Call us or message us on WhatsApp. We also offer delivery.'],
stars:['5 nga 5 yje','5 out of 5 stars'],galP:['Çaste nga Mik Mak — aroma e byrekut të sapopjekur, petët e arta të lakrorit dhe ngrohtësia e saçit','Moments from Mik Mak — the aroma of freshly baked byrek, the golden layers of lakror and the warmth of the saç'],
t_home:['Mik Mak — Ushqim tradicional shqiptar në Korçë','Mik Mak — Traditional Albanian food in Korçë'],d_home:['Mik Mak: byrek, lakror, petanik dhe pispili misri në Korçë.','Mik Mak: byrek, lakror, petanik and pispili misri in Korçë.'],
t_about:['Rreth nesh — Mik Mak','About Us — Mik Mak'],d_about:['Historia e Mik Mak që nga 2009.','The history of Mik Mak since 2009.'],
t_menu:['Menuja — Mik Mak','Menu — Mik Mak'],d_menu:['Byrek, lakror me dy petë, petanik dhe pispili misri me çmime.','Byrek, lakror, petanik and pispili misri with prices.'],
t_gallery:['Galeria — Mik Mak','Gallery — Mik Mak'],d_gallery:['Foto nga Mik Mak.','Photos from Mik Mak.'],
t_reviews:['Vlerësime — Mik Mak','Reviews — Mik Mak'],d_reviews:['Vlerësimet e klientëve të Mik Mak.','Customer reviews of Mik Mak.'],
t_faq:['Pyetje të shpeshta — Mik Mak','FAQ — Mik Mak'],d_faq:['Pyetje të shpeshta për Mik Mak në Korçë.','Frequently asked questions about Mik Mak in Korçë.'],
t_contact:['Kontakt — Mik Mak','Contact — Mik Mak'],d_contact:['Porosit me WhatsApp ose telefon. Bulevardi "Republika", Rruga "Jani Dudo", Korçë.','Order by WhatsApp or phone. "Republika" Boulevard, "Jani Dudo" Street, Korçë.']};
const E={'qepë':'onion','domate':'tomato','presh':'leek','gjizë':'cottage cheese','kos':'yogurt','vezë':'eggs','spinaq':'spinach','hithra':'nettles','lëmpjeta':'lëmpjeta (wild greens)','kungull':'pumpkin','qumësht':'milk','lakër e bardhë turshi':'pickled white cabbage','qepë të njoma':'spring onions','mish i grirë viçi':'minced veal','mëlçi e bardhë viçi':'veal "white liver" (mëlçi e bardhë)','oriz':'rice','fasule':'beans','pulë':'chicken','arra':'walnuts'};
const F=[['QEPË DOMATE','qepë,domate'],['PRESH E GJIZË','presh,gjizë,kos,vezë'],['GJIZË KOS E VEZË','gjizë,kos,vezë'],['SPINAQ','spinaq,gjizë,kos,vezë'],['HITHRA','hithra,gjizë,kos,vezë'],['LËMPJETA','lëmpjeta,gjizë,kos,vezë'],['MIX JESHILE','spinaq,hithra,lëmpjeta,gjizë,kos,vezë'],['KUNGULL','kungull,qumësht,vezë'],['ARME','lakër e bardhë turshi'],['QEPË TË NJOMA','qepë të njoma,gjizë,kos,vezë'],['MISH I GRIRË','mish i grirë viçi,qepë,domate',1],['MËLÇI E BARDHË','mëlçi e bardhë viçi,qepë,oriz,domate',1]];
const CATS=[
{id:'byrek',pr:[['fam5','1,500 L'],['pjese','100 L']],items:F},
{id:'lakror',pr:[['fam4','1,000 L'],['kg','800 L/kg']],items:F},
{id:'petanik',port:1,items:[['FASULE','fasule',0,'1,500 L'],['PULË DHE ARRA','pulë,arra',0,'2,000 L']]},
{id:'pispili',port:1,items:[['PRESH','presh,gjizë',0,'1,500 L'],['MIX JESHILE','spinaq,hithra',0,'1,500 L']]}];
/* Google reviews: original text in its original language, unedited. Fields: name, Google profile id, language, text (\n = new line). */
const GM='https://www.google.com/maps/contrib/',REVS=[
['Artid Gjylameti','112031313814137358606','en','I use all time this Lakrori place,, I like too call,, always,,always I get lakror in this place,, I am so happy too order lakror,, and i enjoy the lakror from his place,, I like too say all employees\nThank thank you for your job,, ,, please keep doing this tradition lakror from Korca,,,\nThank you all,,'],
['Eloïse Dasse-Hartaut','112298899807611489445','en','Excellent!'],
['Σοφια Λασκαρη','111146708977252158536','el','Πολύ νόστιμη πιτα!!. Σαν τα περεκ. Οι κυριες που μας εξυπηρέτησαν πολύ ευγενικές!'],
['Oliver Sahatciu','109256445138566171552','sq','Kemi ngrene sot ne 14/02/2026 nje super lakror me gjize veze dhe kos ne Korce me familjen saqe morem nji me vete por per nje gje u penduam qe smorem 2 lakror me vete dhe jo nje dhe kjo qe morem me vete ishte 10 mije lek dhe kutia ishte e mbushur plot dhe per cmimin qe kishte ishte me te vertete nje gje qe ja vlente e le mos te flasim per shijen e mrekullueshme qe kishte pastaj.Ju sygjeroj te gjithve te beni nje udhetim ne korce e te provoni lakrorin tek mik maku se ishte super!🥰'],
['Arben Zonja','116571148710415651935','sq','Lakrore te persosur me shije korcare'],
['Suzanne Hooker','113283795922027081190','en','Delicious lakror and friendly service. I came her multiple times and tried several varieties. Very popular with locals.']];
const esc=s=>s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
let lang='sq';try{lang=new URLSearchParams(location.search).get('lang')||localStorage.getItem('lang')||'sq'}catch(e){}
if(lang!=='en')lang='sq';
const t=k=>(T[k]||[k,k])[lang==='en'?1:0],ing=s=>s.split(',').map(x=>lang==='en'?E[x]||x:x).join(', ');
const ph=(src,alt,label)=>src?`<figure class="ph has" tabindex="0" role="button" aria-label="${alt}"><img src="${src}" alt="${alt}" loading="lazy" decoding="async"></figure>`:`<figure class="ph" aria-hidden="true"><span><b>✦</b>${label}</span></figure>`;
const IC={pin:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.6"/></svg>',
tel:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h3.5l1.7 4.3-2.2 1.4a11 11 0 0 0 6.3 6.3l1.4-2.2L20 15.5V19a1.5 1.5 0 0 1-1.6 1.5C10.6 20 4 13.4 3.5 5.6A1.5 1.5 0 0 1 5 4z"/></svg>',
wa:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4.5 19.5l1.2-3.6A8 8 0 1 1 8.4 18.6z"/><path d="M9.3 8.6c.2 2.6 2.4 5 5.2 5.6l.9-1.1-1.6-.8-.6.6c-.9-.4-1.7-1.2-2.1-2.1l.6-.6-.8-1.6z"/></svg>',
ig:'<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r=".9" class="f"/></svg>',
fb:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M13.5 21v-7.5h2.6l.4-3h-3V8.6c0-.9.3-1.5 1.6-1.5h1.6V4.4c-.3 0-1.2-.1-2.3-.1-2.3 0-3.9 1.4-3.9 4v2.2H7.9v3h2.6V21"/></svg>',
out:'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 16L16 8M9 8h7v7"/></svg>'};
const contactBtns=()=>TEL.map(n=>`<a class="btn ghost" href="tel:${n}">${t('call')} ${n}</a>`).join('')+`<a class="btn" href="https://wa.me/${WA}" target="_blank" rel="noopener">${t('wa')}</a>`;
function chrome(){const q=lang==='en'?'?lang=en':'';
$('#hdr').innerHTML=`<div class="bar"><a class="logo" href="index.html${q}" aria-label="Mik Mak">MIK MAK</a><div class="right"><div class="lang" role="group" aria-label="Language"><button type="button" data-l="sq" aria-pressed="${lang==='sq'}" lang="sq">SQ</button><button type="button" data-l="en" aria-pressed="${lang==='en'}" lang="en">EN</button></div><button class="burger" type="button" aria-expanded="false" aria-controls="nv" aria-label="${t('navOpen')}"><span></span><span></span><span></span></button></div><nav id="nv" aria-label="Main"><ul>${PAGES.map(([k,f])=>`<li><a href="${f}${q}"${k===PG?' aria-current="page"':''}>${t('n_'+k)}</a></li>`).join('')}</ul></nav></div>`;
$('#ftr').innerHTML=`<div class="f"><div><a class="fw" href="index.html${q}">MIK MAK</a><p>${t('tag')}</p></div><div><h3>${t('ftContact')}</h3><address><a href="${MAPURL}" target="_blank" rel="noopener noreferrer">${ADDR[lang==='en'?1:0]}</a></address><ul class="ft-tel">${TEL.map(n=>`<li><a href="tel:${n}">${n}</a></li>`).join('')}</ul></div><div><h3>${t('ftFollow')}</h3><ul class="ft-soc"><li><a href="${FB}" target="_blank" rel="noopener noreferrer"><span class="ft-ic">${IC.fb}</span>Facebook</a></li><li><a href="${IG}" target="_blank" rel="noopener noreferrer"><span class="ft-ic">${IC.ig}</span>Instagram</a></li></ul></div></div><p class="copy">© 2009–2026 Mik Mak</p>`;}
const slots=(list,n)=>{const a=Array.isArray(list)&&list.length?list:Array(n).fill('');return a.map(s=>ph(s,'Mik Mak',t('soon'))).join('')};
const gal=(n,o=0)=>{const g=(C.gallery||[]).slice(o,n?o+n:undefined);return g.length?g.map(x=>ph(x.src,x[lang]||x.sq||'Mik Mak','')).join(''):Array(n||6).fill(ph('','',t('soon'))).join('')};
function page(){
if(PG==='home'){const v=$('#heroVideo');if(v&&C.heroVideo){if(!v.getAttribute('src'))v.src=C.heroVideo;if(C.heroPoster)v.poster=C.heroPoster;v.closest('.hero').classList.add('hasvid')}
const HP=C.homeDishPhotos||{};
$('#dishList').innerHTML=[['byrek','1,500 L'],['lakror','1,000 L'],['petanik','1,500 L'],['pispili','1,500 L']].map(([k,p],i)=>`<div class="dish rv"><div class="dp">${ph(HP[k],t('d_'+k),t('soon'))}</div><div class="dt"><span class="n">0${i+1}</span><a class="nm" href="menu.html#${k}">${t('d_'+k)}</a></div><p class="ds">${t('ds_'+k)}</p><p class="pz">${p}</p><a class="ar" href="menu.html#${k}" aria-label="${t('seeMenu')}">→</a></div>`).join('');
$('#introImgs').innerHTML=slots(C.homeIntroPhotos,2);$('#galPrev').innerHTML=gal(3)}
if(PG==='home')$('#contactBtns').innerHTML=contactBtns();
/* About timeline: line icons (cutlery, domed serving dish, chef's hat) */
const TLI=['<path d="M6 3v5.5a2 2 0 0 0 4 0V3M8 3v5.5M8 10.5V21"/><ellipse cx="13.5" cy="6.5" rx="2" ry="3.5"/><path d="M13.5 10v11M18 21V3c1.9 1.6 2.6 4.6 2.6 8.4H18"/>',
'<path d="M4.5 16.5a7.5 7.5 0 0 1 15 0M2.5 16.5h19M5.5 19.5h13"/><circle cx="12" cy="7.6" r="1.1"/><path d="M8 12.6a4.6 4.6 0 0 1 2.4-2.2"/>',
'<path d="M7.5 14a3.6 3.6 0 0 1-.6-7.1 4.2 4.2 0 0 1 7.6-1.8 3.6 3.6 0 0 1 3 6.6 3.4 3.4 0 0 1-1 .4M7.5 12.5V20h9v-8.2M7.5 17h9"/>'];
if(PG==='about'){$('#tl').innerHTML=[[2009,1],[2020,2],[2026,3]].map(([y,i])=>`<li class="rv"><span class="tl-ic" aria-hidden="true"><svg viewBox="0 0 24 24">${TLI[i-1]}</svg></span><span class="y">${y}</span><h3>${t('tl'+i)}</h3><p>${t('tl'+i+'p')}</p>${i===3?`<a class="lnk" href="menu.html${lang==='en'?'?lang=en':''}">${t('seeMenu')}</a>`:''}</li>`).join('');$('#aboutImgs').innerHTML=slots(C.aboutPhotos,2)}
if(PG==='menu'){$('#chips').innerHTML=CATS.map(c=>`<a href="#${c.id}" data-c="${c.id}">${t(c.id)}</a>`).join('');
$('#menuCats').innerHTML=CATS.map((c,ci)=>{const photos=(C.menuPhotos||{})[c.id]||[];
return `<article class="cat t${ci}${ci%2?' flip':''}" id="${c.id}"><div class="ci"><header class="cat-h rv"><span class="num">0${ci+1}</span><h2>${t(c.id)}</h2></header>
<div class="cat-b"><div class="mosaic m${photos.length} lb-group rv">${photos.map((s,i)=>ph(s,t(c.id)+' '+(i+1),t('photo')+' '+(i+1))).join('')}</div>
<div class="cat-r rv">${c.pr?`<dl class="prices">${c.pr.map(([k,p])=>`<div><dt>${t(k)}</dt><dd>${p}</dd></div>`).join('')}</dl><h3>${t('fillings')}</h3>`:`<p class="port">${t('for5')}</p>`}
<ol class="items${c.pr?' nums':''}">${c.items.map(([n,g,x,p])=>`<li><span class="nm">${n}</span>${p?`<span class="pp">${p}</span>`:''}${x?`<span class="plus">${t('extra')}: +500 L</span>`:''}<small>${ing(g)}</small></li>`).join('')}</ol></div></div></div></article>`}).join('')}
if(PG==='reviews')$('#revs').innerHTML=REVS.map(([n,id,lg,x])=>`<blockquote class="rev rv${x.length>180?' long':''}" lang="${lg}"><span class="q" aria-hidden="true">“</span>${x.split('\n').map(p=>`<p>${esc(p)}</p>`).join('')}<footer lang="${lang}"><span class="stars" role="img" aria-label="${t('stars')}">★★★★★</span> — <a href="${GM}${id}/reviews?hl=sq-AL" target="_blank" rel="noopener" lang="und">${esc(n)}</a></footer></blockquote>`).join('');
if(PG==='faq'){const open=[...document.querySelectorAll('.faq-q[aria-expanded=true]')].map(b=>b.id);
$('#faq').innerHTML=[1,2,3,4,5].map(i=>`<h2 class="fq"><button class="faq-q" id="q${i}" aria-expanded="${open.includes('q'+i)}" aria-controls="a${i}"><span class="fn">0${i}</span><span>${t('q'+i)}</span></button></h2><div class="faq-a" id="a${i}" role="region" aria-labelledby="q${i}" ${open.includes('q'+i)?'':'hidden'}><p>${t('a'+i)}</p></div>`).join('')}
if(PG==='contact'){const nw=`<span class="sr">(${t('cNew')})</span>`;
$('#locPh').innerHTML=ph(C.contactLocationPhoto,t('locAlt'),t('soon'));
$('#addr').innerHTML=`<ul class="cinfo">
<li><span class="ci-ic">${IC.pin}</span><div><span class="ci-l">${t('cAddr')}</span><a class="ci-v" href="${MAPURL}" target="_blank" rel="noopener noreferrer">${ADDR[lang==='en'?1:0]}<span class="ci-s">${t('cMapOpen')} ↗</span>${nw}</a></div></li>
<li><span class="ci-ic">${IC.tel}</span><div><span class="ci-l">${t('cPhone')}</span>${TEL.map(n=>`<a class="ci-v" href="tel:${n}">${n.replace(/^(\d{3})(\d{3})(\d+)$/,'$1 $2 $3')}</a>`).join('')}</div></li>
<li><span class="ci-ic">${IC.wa}</span><div><span class="ci-l">WhatsApp</span><a class="ci-v" href="#wf" data-scroll="wf">${t('cWaTxt')} →</a></div></li></ul>`;
const mf=$('#mapFrame'),ms=`https://maps.google.com/maps?q=${encodeURIComponent(MAPQ)}&hl=${lang}&z=17&output=embed`;if(mf&&mf.getAttribute('src')!==ms)mf.setAttribute('src',ms);
const card=(k,url,handle)=>`<a class="soc-card ${k}" href="${url}" target="_blank" rel="noopener noreferrer"><span class="soc-top"><span class="soc-av" aria-hidden="true"><b>MM</b></span><span class="soc-id"><b>Mik Mak</b><small>${handle}</small></span><span class="soc-ic">${IC[k]}</span></span><span class="soc-sub">${t(k+'Sub')}</span><span class="soc-btn">${t(k+'Cta')} ${IC.out}</span><span class="sr">(${t('cNew')})</span></a>`;
$('#soc').innerHTML=card('ig',IG,'@mik_mak_korce')+card('fb',FB,'@mik.mak.3705')}
if(PG==='gallery'){const g=C.gallery||[];$('#gal').innerHTML=Array.from({length:Math.max(9,g.length)},(_,i)=>g[i]?ph(g[i].src,g[i][lang]||g[i].sq||'Mik Mak',''):ph('','',t('soon'))).join('')}
if(PG==='menu')spy()}
/* Menu: highlight the chip of the category currently in view */
function spy(){const ch=$('#chips');if(!ch)return;const line=ch.getBoundingClientRect().bottom+Math.min(160,innerHeight*.25);let cur=CATS[0].id;
CATS.forEach(c=>{const el=document.getElementById(c.id);if(el&&el.getBoundingClientRect().top<=line)cur=c.id});
if(innerHeight+scrollY>=document.documentElement.scrollHeight-4)cur=CATS[CATS.length-1].id;
ch.querySelectorAll('a').forEach(a=>{const on=a.dataset.c===cur;a.classList.toggle('on',on);if(on)a.setAttribute('aria-current','true');else a.removeAttribute('aria-current')})}
if(PG==='menu'){let tk=0;const q=()=>{if(!tk){tk=1;requestAnimationFrame(()=>{tk=0;spy()})}};addEventListener('scroll',q,{passive:true});addEventListener('resize',q)}
function draw(){document.documentElement.lang=lang;chrome();page();
document.querySelectorAll('[data-i]').forEach(e=>e.textContent=t(e.dataset.i));
document.querySelectorAll('[data-ph]').forEach(e=>e.placeholder=t(e.dataset.ph));
document.querySelectorAll('main a[href*=".html"]').forEach(a=>{const[h,hs='']=a.getAttribute('href').split('#');a.setAttribute('href',h.split('?')[0]+(lang==='en'?'?lang=en':'')+(hs?'#'+hs:''))});document.title=t('t_'+PG);const m=document.querySelector('meta[name=description]');if(m)m.content=t('d_'+PG);
try{localStorage.setItem('lang',lang)}catch(e){}
const rv=document.querySelectorAll('.rv:not(.in)');
if('IntersectionObserver' in window&&!matchMedia('(prefers-reduced-motion:reduce)').matches){document.documentElement.classList.add('rvon');const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{rootMargin:'0px 0px -6% 0px'});rv.forEach(x=>io.observe(x))}else rv.forEach(x=>x.classList.add('in'))}
document.addEventListener('click',e=>{const b=e.target.closest('[data-l]');
if(b){lang=b.dataset.l;draw();return}
const bg=e.target.closest('.burger');if(bg){const o=$('#nv').classList.toggle('open');bg.setAttribute('aria-expanded',o);bg.setAttribute('aria-label',t(o?'navClose':'navOpen'));return}
const q=e.target.closest('.faq-q');if(q){const o=q.getAttribute('aria-expanded')==='true';q.setAttribute('aria-expanded',!o);document.getElementById(q.getAttribute('aria-controls')).hidden=o;return}
const sc=e.target.closest('[data-scroll]');if(sc){const el=document.getElementById(sc.dataset.scroll);if(el){e.preventDefault();el.classList.add('in');let y=0,n=el;while(n){y+=n.offsetTop;n=n.offsetParent}scrollTo({top:Math.max(0,y-($('#hdr')?$('#hdr').offsetHeight:0)-20),behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth'});const fld=el.querySelector('textarea');if(fld)setTimeout(()=>fld.focus({preventScroll:true}),450)}return}
const f=e.target.closest('figure.has');if(f)openLb(f)});
document.addEventListener('keydown',e=>{const f=e.target.closest&&e.target.closest('figure.has');if(f&&(e.key==='Enter'||e.key===' ')){e.preventDefault();openLb(f)}});
/* Lightbox */
let items=[],idx=0,last=null;const lb=document.createElement('div');lb.className='lb';lb.setAttribute('role','dialog');lb.setAttribute('aria-modal','true');
lb.innerHTML='<button class="x" aria-label="Close">×</button><button class="p" aria-label="Previous">‹</button><img alt=""><button class="n" aria-label="Next">›</button>';document.body.appendChild(lb);
const li=lb.querySelector('img');
function show(){const im=items[idx].querySelector('img');li.src=im.currentSrc||im.src;li.alt=im.alt;lb.querySelectorAll('.p,.n').forEach(b=>b.style.display=items.length>1?'':'none')}
function openLb(f){const g=f.closest('.lb-group')||document;items=[...g.querySelectorAll('figure.has')];idx=items.indexOf(f);last=f;show();lb.classList.add('on');lb.querySelector('.x').focus()}
function closeLb(){lb.classList.remove('on');li.removeAttribute('src');if(last)last.focus()}
const step=d=>{idx=(idx+d+items.length)%items.length;show()};
lb.addEventListener('click',e=>{if(e.target.classList.contains('x')||e.target===lb)closeLb();else if(e.target.classList.contains('p'))step(-1);else if(e.target.classList.contains('n'))step(1)});
document.addEventListener('keydown',e=>{if(!lb.classList.contains('on'))return;if(e.key==='Escape')closeLb();if(e.key==='ArrowLeft'&&items.length>1)step(-1);if(e.key==='ArrowRight'&&items.length>1)step(1)});
let sx=0;lb.addEventListener('touchstart',e=>sx=e.touches[0].clientX,{passive:true});lb.addEventListener('touchend',e=>{const d=e.changedTouches[0].clientX-sx;if(Math.abs(d)>50&&items.length>1)step(d<0?1:-1)});
/* WhatsApp form */
document.addEventListener('submit',e=>{if(e.target.id!=='wf')return;e.preventDefault();const f=e.target,st=$('#st'),m=f.m.value.trim();
if(!m){st.className='err';st.textContent=t('need');f.m.focus();return}
const url=`https://wa.me/${WA}?text=`+encodeURIComponent(m);
st.className='';st.textContent='';const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener';document.body.appendChild(a);a.click();a.remove()});
/* Marquee: two identical groups, each wider than the screen; the track moves exactly one group width, so the loop is seamless. */
function strip(){const s=document.querySelector('.strip');if(!s)return;const N=['BYREK','LAKROR','PETANIK','PISPILI MISRI'];
const g='<div class="grp">'+Array(8).fill(N.map(n=>`<span>${n}</span><span class="d">✦</span>`).join('')).join('')+'</div>';
s.innerHTML=`<div class="track">${g}${g}</div>`;
const fit=()=>{const w=s.querySelector('.grp').offsetWidth;if(w)s.firstElementChild.style.setProperty('--dur',(w/9.1).toFixed(1)+'s')};fit();
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(fit)}
draw();strip();
if(location.hash){const el=document.getElementById(decodeURIComponent(location.hash.slice(1)));if(el)el.scrollIntoView()}
})();
